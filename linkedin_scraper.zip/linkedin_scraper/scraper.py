#!/usr/bin/env python3
"""
LinkedIn Profile Scraper - Real Desktop App
Uses LinkedIn's Voyager API with your li_at session cookie.
No paid plans, no API keys - just your own LinkedIn session.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import requests
import json
import csv
import time
import re
import os
from datetime import datetime

# ─── COLORS ───────────────────────────────────────────
BG      = "#F3F6FB"
WH      = "#FFFFFF"
LI_BLUE = "#0A66C2"
LI_DARK = "#084fa1"
NAVY    = "#1B1B2F"
MUTED   = "#6B7280"
BORDER  = "#DDE3EE"
OK      = "#16A34A"
ERR     = "#DC2626"
SURF    = "#F3F6FB"
TAG_BG  = "#EFF6FF"
TAG_FG  = "#1D4ED8"

FONT    = ("Segoe UI", 10)
FONT_B  = ("Segoe UI", 10, "bold")
FONT_SM = ("Segoe UI", 9)
FONT_LG = ("Segoe UI", 12, "bold")
FONT_XL = ("Segoe UI", 14, "bold")
MONO    = ("Consolas", 9)


# ─── VOYAGER API ──────────────────────────────────────
BASE = "https://www.linkedin.com"
HEADERS_BASE = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/vnd.linkedin.normalized+json+2.1",
    "Accept-Language": "en-US,en;q=0.9",
    "X-RestLi-Protocol-Version": "2.0.0",
    "X-Li-Lang": "en_US",
    "Referer": "https://www.linkedin.com/",
    "X-Requested-With": "XMLHttpRequest",
}

def get_headers(cookie):
    h = dict(HEADERS_BASE)
    h["Cookie"] = f"li_at={cookie}"
    # Get CSRF token from cookie if present
    h["Csrf-Token"] = "ajax:0000000000000000000"
    return h

def get_slug(url):
    url = url.strip().rstrip('/')
    m = re.search(r'linkedin\.com/in/([^/?#]+)', url)
    return m.group(1) if m else url

def fetch_profile(slug, cookie):
    """Fetch full profile via Voyager API"""
    session = requests.Session()
    session.headers.update(get_headers(cookie))

    # Try full profile endpoint first
    endpoints = [
        f"/voyager/api/identity/dash/profiles?q=memberIdentity&memberIdentity={slug}&decorationId=com.linkedin.voyager.dash.deco.identity.profile.FullProfileWithEntities-93",
        f"/voyager/api/identity/profiles/{slug}/profileView",
        f"/voyager/api/identity/dash/profiles?q=memberIdentity&memberIdentity={slug}",
    ]

    for ep in endpoints:
        try:
            r = session.get(BASE + ep, timeout=15)
            if r.status_code == 200:
                data = r.json()
                profile = parse_profile(data, slug)
                if profile.get('name') and profile['name'] != 'Unknown':
                    return profile
        except Exception:
            continue

    raise Exception(f"Profile not found or access denied for '{slug}'. Check your cookie.")

def parse_profile(data, slug):
    included = data.get('included', [])
    elements = data.get('elements', [])

    # Find main profile object
    profile_obj = None
    for x in included:
        t = x.get('$type', '')
        if 'Profile' in t and x.get('firstName'):
            profile_obj = x
            break

    if not profile_obj:
        # Try elements
        for x in elements:
            if x.get('firstName') or x.get('name'):
                profile_obj = x
                break

    if not profile_obj:
        profile_obj = data.get('profile', data.get('miniProfile', {}))

    p = profile_obj or {}
    first = p.get('firstName', p.get('localizedFirstName', ''))
    last  = p.get('lastName',  p.get('localizedLastName', ''))
    name  = f"{first} {last}".strip() or p.get('name', 'Unknown')

    # Experience
    exp_items = [x for x in included if 'Position' in x.get('$type','') or 'Experience' in x.get('$type','')]
    experience = []
    for e in exp_items[:5]:
        start = e.get('dateRange', {}).get('start', {})
        end   = e.get('dateRange', {}).get('end', {})
        dur   = ""
        if start:
            s = f"{start.get('year','')}".strip()
            en = f"{end.get('year','Present')}".strip() if end else "Present"
            dur = f"{s} – {en}"
        experience.append({
            'role':    e.get('title', e.get('localizedTitle', '')),
            'company': e.get('companyName', e.get('localizedCompanyName', '')),
            'duration': dur,
            'description': e.get('description', '')
        })

    # Education
    edu_items = [x for x in included if 'Education' in x.get('$type','')]
    education = []
    for e in edu_items[:4]:
        education.append({
            'degree': e.get('degreeName', e.get('fieldOfStudy', '')),
            'school': e.get('schoolName', e.get('localizedSchoolName', '')),
            'year':   str(e.get('dateRange', {}).get('end', {}).get('year',''))
        })

    # Skills
    skill_items = [x for x in included if 'Skill' in x.get('$type','')]
    skills = [s.get('name', s.get('localizedName','')) for s in skill_items if s.get('name') or s.get('localizedName')][:15]

    # Image
    image_url = ''
    try:
        pic = p.get('profilePicture', p.get('picture', {}))
        if pic:
            vi = pic.get('displayImageReference', {}).get('vectorImage', {})
            root = vi.get('rootUrl', '')
            arts = vi.get('artifacts', [])
            art = next((a for a in arts if a.get('width', 0) >= 100), arts[0] if arts else None)
            if art and root:
                image_url = root + art.get('fileIdentifyingUrlPathSegment','')
    except Exception:
        pass

    return {
        'name':        name,
        'headline':    p.get('headline', p.get('localizedHeadline', '')),
        'location':    p.get('locationName', p.get('geoLocationName', '')),
        'about':       p.get('summary', ''),
        'experience':  experience,
        'education':   education,
        'skills':      skills,
        'followers':   str(p.get('followersCount', '')),
        'connections': str(p.get('connectionsCount', '')),
        'url':         f"https://www.linkedin.com/in/{p.get('publicIdentifier', slug)}",
        'image':       image_url,
    }

def search_people(keywords, location, count, cookie):
    """Search LinkedIn people"""
    session = requests.Session()
    session.headers.update(get_headers(cookie))

    q = keywords
    if location:
        q = f"{keywords} {location}".strip()

    ep = (
        f"/voyager/api/search/dash/clusters"
        f"?decorationId=com.linkedin.voyager.dash.deco.search.SearchClusterCollection-175"
        f"&origin=GLOBAL_SEARCH_HEADER"
        f"&q=all"
        f"&query=(keywords:{requests.utils.quote(q)},flagshipSearchIntent:SEARCH_SRP,"
        f"queryParameters:(resultType:List((value:PEOPLE,category:SEARCH_RESULT_TYPE))),"
        f"includeFiltersInResponse:false)"
        f"&count={count}&start=0"
    )

    r = session.get(BASE + ep, timeout=15)
    if r.status_code != 200:
        raise Exception(f"Search failed: HTTP {r.status_code}. Check your cookie.")

    data = r.json()
    included = data.get('included', [])
    mini_profiles = [x for x in included if 'MiniProfile' in x.get('$type','') and x.get('firstName')]

    results = []
    for p in mini_profiles[:count]:
        first = p.get('firstName','')
        last  = p.get('lastName','')
        slug  = p.get('publicIdentifier','')
        results.append({
            'name':        f"{first} {last}".strip(),
            'headline':    p.get('occupation',''),
            'location':    '',
            'about':       '',
            'experience':  [],
            'education':   [],
            'skills':      [],
            'followers':   '',
            'connections': '',
            'url':         f"https://www.linkedin.com/in/{slug}" if slug else '',
            'image':       '',
        })
    return results


# ─── GUI ──────────────────────────────────────────────
class LinkedInScraper(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LinkedIn Profile Scraper")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.configure(bg=BG)
        self.results = []
        self.cookie  = tk.StringVar()
        self._load_cookie()
        self._build_ui()

    def _load_cookie(self):
        try:
            cfg = os.path.join(os.path.expanduser("~"), ".li_scraper_cookie")
            if os.path.exists(cfg):
                with open(cfg) as f:
                    self.cookie.set(f.read().strip())
        except Exception:
            pass

    def _save_cookie(self, val):
        try:
            cfg = os.path.join(os.path.expanduser("~"), ".li_scraper_cookie")
            with open(cfg, 'w') as f:
                f.write(val)
        except Exception:
            pass

    def _build_ui(self):
        # ── TOP BAR ──
        top = tk.Frame(self, bg=LI_BLUE, height=52)
        top.pack(fill='x')
        top.pack_propagate(False)
        tk.Label(top, text="  🔗 LinkedIn Profile Scraper", font=("Segoe UI", 14, "bold"),
                 bg=LI_BLUE, fg='white').pack(side='left', pady=10)
        tk.Label(top, text="Real data via Voyager API  ", font=FONT_SM,
                 bg=LI_BLUE, fg='rgba(255,255,255,0.7)').pack(side='right', pady=10)

        # ── NOTEBOOK (TABS) ──
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TNotebook', background=BG, borderwidth=0)
        style.configure('TNotebook.Tab', background=WH, foreground=MUTED,
                        font=FONT_B, padding=[16,8], borderwidth=0)
        style.map('TNotebook.Tab',
                  background=[('selected', LI_BLUE)],
                  foreground=[('selected', 'white')])

        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True, padx=0, pady=0)

        # Tab 1: Scrape
        self.tab_scrape = tk.Frame(nb, bg=BG)
        nb.add(self.tab_scrape, text="  🔍 Scrape by URL  ")

        # Tab 2: Search
        self.tab_search = tk.Frame(nb, bg=BG)
        nb.add(self.tab_search, text="  🌐 Search People  ")

        # Tab 3: Settings
        self.tab_settings = tk.Frame(nb, bg=BG)
        nb.add(self.tab_settings, text="  ⚙️ Cookie Setup  ")

        self._build_scrape_tab()
        self._build_search_tab()
        self._build_settings_tab()

        # Status bar
        self.status_var = tk.StringVar(value="Ready — Add your li_at cookie in ⚙️ Cookie Setup tab")
        sb = tk.Frame(self, bg=BORDER, height=28)
        sb.pack(fill='x', side='bottom')
        sb.pack_propagate(False)
        tk.Label(sb, textvariable=self.status_var, font=FONT_SM,
                 bg=BORDER, fg=MUTED, anchor='w').pack(fill='x', padx=10, pady=5)

    # ── SCRAPE TAB ──────────────────────────────────────
    def _build_scrape_tab(self):
        pane = tk.PanedWindow(self.tab_scrape, orient='horizontal', bg=BG,
                              sashwidth=4, sashrelief='flat')
        pane.pack(fill='both', expand=True)

        # Left panel
        left = tk.Frame(pane, bg=WH, width=300)
        pane.add(left, minsize=260)
        left.pack_propagate(False)

        pad = tk.Frame(left, bg=WH)
        pad.pack(fill='both', expand=True, padx=16, pady=16)

        tk.Label(pad, text="LinkedIn Profile URLs", font=FONT_B, bg=WH, fg=NAVY).pack(anchor='w')
        tk.Label(pad, text="One URL per line", font=FONT_SM, bg=WH, fg=MUTED).pack(anchor='w', pady=(2,6))

        self.url_text = tk.Text(pad, height=10, font=MONO, bg=SURF, fg=NAVY,
                                relief='flat', bd=1, highlightthickness=1,
                                highlightcolor=LI_BLUE, highlightbackground=BORDER,
                                insertbackground=NAVY, wrap='none')
        self.url_text.pack(fill='x')
        self.url_text.insert('1.0',
            "https://www.linkedin.com/in/williamhgates\n"
            "https://www.linkedin.com/in/satyanadella\n"
        )

        tk.Frame(pad, bg=BORDER, height=1).pack(fill='x', pady=12)

        # Export options
        tk.Label(pad, text="Export format", font=FONT_B, bg=WH, fg=NAVY).pack(anchor='w', pady=(0,6))
        self.export_fmt = tk.StringVar(value='json')
        fmts = tk.Frame(pad, bg=WH)
        fmts.pack(fill='x')
        for fmt in ['json', 'csv', 'xlsx']:
            tk.Radiobutton(fmts, text=fmt.upper(), variable=self.export_fmt,
                           value=fmt, bg=WH, fg=NAVY, font=FONT,
                           activebackground=WH, selectcolor=LI_BLUE).pack(side='left', padx=4)

        tk.Frame(pad, bg=BORDER, height=1).pack(fill='x', pady=12)

        # Scrape button
        self.scrape_btn = tk.Button(pad, text="⚡ Scrape Profiles",
                                    font=FONT_B, bg=LI_BLUE, fg='white',
                                    relief='flat', cursor='hand2',
                                    command=self._run_scrape, pady=10)
        self.scrape_btn.pack(fill='x')

        # Progress
        self.scrape_progress = ttk.Progressbar(pad, mode='indeterminate')
        self.scrape_progress.pack(fill='x', pady=(8,0))

        # Right panel
        right = tk.Frame(pane, bg=BG)
        pane.add(right, minsize=500)
        self._build_results_panel(right, 'scrape')

    # ── SEARCH TAB ──────────────────────────────────────
    def _build_search_tab(self):
        pane = tk.PanedWindow(self.tab_search, orient='horizontal', bg=BG,
                              sashwidth=4, sashrelief='flat')
        pane.pack(fill='both', expand=True)

        left = tk.Frame(pane, bg=WH, width=300)
        pane.add(left, minsize=260)
        left.pack_propagate(False)

        pad = tk.Frame(left, bg=WH)
        pad.pack(fill='both', expand=True, padx=16, pady=16)

        def field(label, var, placeholder=''):
            tk.Label(pad, text=label, font=FONT_B, bg=WH, fg=NAVY).pack(anchor='w', pady=(8,2))
            e = tk.Entry(pad, textvariable=var, font=FONT, bg=SURF, fg=NAVY,
                         relief='flat', bd=1, highlightthickness=1,
                         highlightcolor=LI_BLUE, highlightbackground=BORDER)
            e.pack(fill='x', ipady=6)
            if placeholder and not var.get():
                e.insert(0, placeholder)
                e.config(fg=MUTED)
                def on_focus_in(event, entry=e, v=var):
                    if entry.get() == placeholder:
                        entry.delete(0, 'end')
                        entry.config(fg=NAVY)
                def on_focus_out(event, entry=e, ph=placeholder, v=var):
                    if not entry.get():
                        entry.insert(0, ph)
                        entry.config(fg=MUTED)
                        v.set('')
                e.bind('<FocusIn>', on_focus_in)
                e.bind('<FocusOut>', on_focus_out)
            return e

        self.s_keywords = tk.StringVar()
        self.s_location = tk.StringVar()
        self.s_company  = tk.StringVar()
        self.s_count    = tk.StringVar(value='10')

        field("Keywords / Name", self.s_keywords, "e.g. Priya Sharma engineer")
        field("Location", self.s_location, "e.g. Mumbai, Bangalore")
        field("Company", self.s_company, "e.g. TCS, Infosys, Google")

        tk.Label(pad, text="Results count", font=FONT_B, bg=WH, fg=NAVY).pack(anchor='w', pady=(8,2))
        count_frame = tk.Frame(pad, bg=WH)
        count_frame.pack(fill='x')
        for n in ['5', '10', '20', '50']:
            tk.Radiobutton(count_frame, text=n, variable=self.s_count,
                           value=n, bg=WH, fg=NAVY, font=FONT,
                           activebackground=WH, selectcolor=LI_BLUE).pack(side='left', padx=4)

        tk.Label(pad, text="Gender filter", font=FONT_B, bg=WH, fg=NAVY).pack(anchor='w', pady=(12,4))
        self.gender_filter = tk.StringVar(value='Any')
        gf = tk.Frame(pad, bg=WH)
        gf.pack(fill='x')
        for g in ['Any', 'Male', 'Female']:
            tk.Radiobutton(gf, text=g, variable=self.gender_filter,
                           value=g, bg=WH, fg=NAVY, font=FONT,
                           activebackground=WH, selectcolor=LI_BLUE).pack(side='left', padx=4)

        tk.Frame(pad, bg=BORDER, height=1).pack(fill='x', pady=12)

        self.search_btn = tk.Button(pad, text="🔍 Search LinkedIn",
                                    font=FONT_B, bg=LI_BLUE, fg='white',
                                    relief='flat', cursor='hand2',
                                    command=self._run_search, pady=10)
        self.search_btn.pack(fill='x')

        self.search_progress = ttk.Progressbar(pad, mode='indeterminate')
        self.search_progress.pack(fill='x', pady=(8,0))

        right = tk.Frame(pane, bg=BG)
        pane.add(right, minsize=500)
        self._build_results_panel(right, 'search')

    # ── SETTINGS TAB ────────────────────────────────────
    def _build_settings_tab(self):
        f = tk.Frame(self.tab_settings, bg=BG)
        f.pack(fill='both', expand=True, padx=40, pady=30)

        # Title
        tk.Label(f, text="🍪 LinkedIn Cookie Setup", font=FONT_XL, bg=BG, fg=NAVY).pack(anchor='w')
        tk.Label(f, text="The scraper uses LinkedIn's own internal Voyager API with your session cookie.",
                 font=FONT, bg=BG, fg=MUTED, wraplength=600, justify='left').pack(anchor='w', pady=(4,16))

        # How to get cookie
        box = tk.Frame(f, bg=LI_BLUE, bd=0)
        box.pack(fill='x', pady=(0,20))
        inner = tk.Frame(box, bg=LI_BLUE)
        inner.pack(fill='x', padx=18, pady=16)
        tk.Label(inner, text="How to get your li_at cookie", font=FONT_B, bg=LI_BLUE, fg='white').pack(anchor='w')
        steps = [
            "1.  Open linkedin.com in Chrome/Edge and log in",
            "2.  Press F12 to open Developer Tools",
            "3.  Go to Application tab → Cookies → https://www.linkedin.com",
            "4.  Find the cookie named  li_at",
            "5.  Click it and copy the full Value (it's a long string starting with AQ...)",
            "6.  Paste it in the field below and click Save",
        ]
        for s in steps:
            tk.Label(inner, text=s, font=FONT, bg=LI_BLUE, fg='white', justify='left').pack(anchor='w', pady=1)

        # Cookie input
        inp_frame = tk.Frame(f, bg=BG)
        inp_frame.pack(fill='x', pady=(0,10))
        tk.Label(inp_frame, text="li_at Cookie Value:", font=FONT_B, bg=BG, fg=NAVY).pack(anchor='w', pady=(0,4))

        row = tk.Frame(inp_frame, bg=BG)
        row.pack(fill='x')

        self.cookie_entry = tk.Entry(row, textvariable=self.cookie, font=MONO,
                                     bg=WH, fg=NAVY, show='•', relief='flat',
                                     bd=1, highlightthickness=1,
                                     highlightcolor=LI_BLUE, highlightbackground=BORDER)
        self.cookie_entry.pack(side='left', fill='x', expand=True, ipady=8, padx=(0,8))

        tk.Button(row, text="👁 Show", font=FONT_SM, bg=SURF, fg=NAVY,
                  relief='flat', cursor='hand2',
                  command=lambda: self.cookie_entry.config(show='' if self.cookie_entry.cget('show') else '•')
                  ).pack(side='left', padx=(0,4))

        tk.Button(row, text="💾 Save Cookie", font=FONT_B, bg=LI_BLUE, fg='white',
                  relief='flat', cursor='hand2', pady=8, padx=14,
                  command=self._do_save_cookie).pack(side='left')

        # Status
        self.cookie_status = tk.Label(f, text="", font=FONT, bg=BG)
        self.cookie_status.pack(anchor='w', pady=4)
        self._refresh_cookie_status()

        # Note
        tk.Frame(f, bg=BORDER, height=1).pack(fill='x', pady=16)
        note = ("⚠️  Your cookie is stored locally on your computer (~/.li_scraper_cookie).\n"
                "It is never sent anywhere except to linkedin.com. "
                "Cookies expire every few weeks — refresh it if you get 401 errors.")
        tk.Label(f, text=note, font=FONT_SM, bg=BG, fg=MUTED,
                 wraplength=600, justify='left').pack(anchor='w')

    def _do_save_cookie(self):
        val = self.cookie.get().strip()
        if not val:
            messagebox.showerror("Error", "Please paste your li_at cookie value first.")
            return
        self._save_cookie(val)
        self._refresh_cookie_status()
        messagebox.showinfo("Saved", "Cookie saved! You can now scrape profiles.")

    def _refresh_cookie_status(self):
        val = self.cookie.get().strip()
        if val:
            preview = val[:12] + "..." + val[-6:] if len(val) > 20 else val
            self.cookie_status.config(text=f"✅  Cookie saved: {preview}", fg=OK)
            self.status_var.set("Ready — Cookie loaded. Paste URLs and click Scrape.")
        else:
            self.cookie_status.config(text="❌  No cookie saved yet. Add your li_at cookie above.", fg=ERR)

    # ── RESULTS PANEL ───────────────────────────────────
    def _build_results_panel(self, parent, tag):
        # Toolbar
        bar = tk.Frame(parent, bg=WH, height=44)
        bar.pack(fill='x')
        bar.pack_propagate(False)
        inner = tk.Frame(bar, bg=WH)
        inner.pack(fill='both', padx=14, pady=8)

        lbl = tk.Label(inner, text="Results will appear here", font=FONT_B, bg=WH, fg=MUTED)
        lbl.pack(side='left')
        setattr(self, f'{tag}_result_label', lbl)

        btn_frame = tk.Frame(inner, bg=WH)
        btn_frame.pack(side='right')
        tk.Button(btn_frame, text="⬇ Export JSON", font=FONT_SM, bg=SURF, fg=NAVY,
                  relief='flat', cursor='hand2', padx=8, pady=4,
                  command=lambda t=tag: self._export('json', t)).pack(side='left', padx=2)
        tk.Button(btn_frame, text="⬇ Export CSV", font=FONT_SM, bg=SURF, fg=NAVY,
                  relief='flat', cursor='hand2', padx=8, pady=4,
                  command=lambda t=tag: self._export('csv', t)).pack(side='left', padx=2)

        tk.Frame(parent, bg=BORDER, height=1).pack(fill='x')

        # Results area with scrollbar
        canvas_frame = tk.Frame(parent, bg=BG)
        canvas_frame.pack(fill='both', expand=True)

        canvas = tk.Canvas(canvas_frame, bg=BG, highlightthickness=0)
        sb = tk.Scrollbar(canvas_frame, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        scroll_frame = tk.Frame(canvas, bg=BG)
        canvas.create_window((0,0), window=scroll_frame, anchor='nw', tags='frame')

        def on_configure(e):
            canvas.configure(scrollregion=canvas.bbox('all'))
            canvas.itemconfig('frame', width=canvas.winfo_width())
        scroll_frame.bind('<Configure>', on_configure)
        canvas.bind('<Configure>', lambda e: canvas.itemconfig('frame', width=e.width))
        canvas.bind_all('<MouseWheel>', lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        setattr(self, f'{tag}_scroll_frame', scroll_frame)
        setattr(self, f'{tag}_canvas', canvas)
        setattr(self, f'{tag}_results', [])

    def _show_results(self, profiles, tag):
        frame = getattr(self, f'{tag}_scroll_frame')
        lbl   = getattr(self, f'{tag}_result_label')

        # Clear existing
        for w in frame.winfo_children():
            w.destroy()

        setattr(self, f'{tag}_results', profiles)

        if not profiles:
            tk.Label(frame, text="No results found.", font=FONT, bg=BG, fg=MUTED).pack(pady=20)
            lbl.config(text="No results", fg=MUTED)
            return

        lbl.config(text=f"✅  {len(profiles)} profile{'s' if len(profiles)!=1 else ''} scraped", fg=OK)

        for i, p in enumerate(profiles):
            self._build_card(frame, p, i)

    def _build_card(self, parent, p, i):
        card = tk.Frame(parent, bg=WH, bd=1, relief='flat',
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(fill='x', padx=14, pady=6)

        # Header
        hdr = tk.Frame(card, bg=WH)
        hdr.pack(fill='x', padx=14, pady=(12,8))

        # Avatar circle
        av = tk.Canvas(hdr, width=46, height=46, bg=WH, highlightthickness=0)
        av.pack(side='left')
        colors = [LI_BLUE,'#1E40AF','#7C3AED','#0891B2','#059669','#B45309']
        h = 0
        for ch in (p.get('name') or ''):
            h = (h*31 + ord(ch)) & 0xFFFF
        color = colors[h % len(colors)]
        av.create_oval(2,2,44,44, fill=color, outline='')
        ini = ''.join([w[0].upper() for w in (p.get('name','?')).split()[:2]]) or '?'
        av.create_text(23,23, text=ini, fill='white', font=("Segoe UI", 13, "bold"))

        info = tk.Frame(hdr, bg=WH)
        info.pack(side='left', fill='x', expand=True, padx=(10,0))

        name_row = tk.Frame(info, bg=WH)
        name_row.pack(fill='x')
        tk.Label(name_row, text=f"#{i+1}  {p.get('name','Unknown')}",
                 font=FONT_LG, bg=WH, fg=NAVY).pack(side='left')
        tk.Label(name_row, text=" ✓ Real", font=FONT_SM, bg='#DCFCE7', fg=OK).pack(side='left', padx=6)

        if p.get('headline'):
            tk.Label(info, text=p['headline'], font=FONT, bg=WH, fg=MUTED,
                     wraplength=500, justify='left').pack(anchor='w')

        meta = []
        if p.get('location'):   meta.append(f"📍 {p['location']}")
        if p.get('followers'):  meta.append(f"👥 {p['followers']} followers")
        if p.get('connections'):meta.append(f"🔗 {p['connections']} connections")
        if meta:
            tk.Label(info, text="   ".join(meta), font=FONT_SM, bg=WH, fg=MUTED).pack(anchor='w')

        # Open LinkedIn button
        if p.get('url'):
            tk.Button(hdr, text="Open LinkedIn ↗", font=FONT_SM, bg=LI_BLUE, fg='white',
                      relief='flat', cursor='hand2', padx=10, pady=5,
                      command=lambda u=p['url']: self._open_url(u)).pack(side='right', anchor='n')

        tk.Frame(card, bg=BORDER, height=1).pack(fill='x', padx=14)

        # Body
        body = tk.Frame(card, bg=WH)
        body.pack(fill='x', padx=14, pady=(8,12))

        col1 = tk.Frame(body, bg=WH)
        col1.pack(side='left', fill='both', expand=True, padx=(0,8))
        col2 = tk.Frame(body, bg=WH)
        col2.pack(side='left', fill='both', expand=True)

        # About
        if p.get('about'):
            tk.Label(col1, text="ABOUT", font=("Segoe UI",8,"bold"), bg=WH, fg=MUTED).pack(anchor='w')
            tk.Label(col1, text=p['about'][:250]+('…' if len(p.get('about',''))>250 else ''),
                     font=FONT_SM, bg=WH, fg=NAVY, wraplength=300, justify='left').pack(anchor='w', pady=(2,8))

        # Experience
        if p.get('experience'):
            tk.Label(col1, text="EXPERIENCE", font=("Segoe UI",8,"bold"), bg=WH, fg=MUTED).pack(anchor='w')
            for e in p['experience'][:3]:
                ef = tk.Frame(col1, bg=SURF, bd=0)
                ef.pack(fill='x', pady=2)
                tk.Frame(ef, bg=LI_BLUE, width=3).pack(side='left', fill='y')
                ei = tk.Frame(ef, bg=SURF)
                ei.pack(side='left', fill='x', expand=True, padx=8, pady=4)
                if e.get('role'):
                    tk.Label(ei, text=e['role'], font=FONT_B, bg=SURF, fg=NAVY).pack(anchor='w')
                co_txt = e.get('company','')
                if e.get('duration'): co_txt += f"  ·  {e['duration']}"
                if co_txt:
                    tk.Label(ei, text=co_txt, font=FONT_SM, bg=SURF, fg=MUTED).pack(anchor='w')

        # Education
        if p.get('education'):
            tk.Label(col2, text="EDUCATION", font=("Segoe UI",8,"bold"), bg=WH, fg=MUTED).pack(anchor='w')
            for e in p['education'][:3]:
                ef = tk.Frame(col2, bg=SURF)
                ef.pack(fill='x', pady=2)
                tk.Frame(ef, bg=LI_BLUE, width=3).pack(side='left', fill='y')
                ei = tk.Frame(ef, bg=SURF)
                ei.pack(side='left', fill='x', expand=True, padx=8, pady=4)
                if e.get('school'):
                    tk.Label(ei, text=e['school'], font=FONT_B, bg=SURF, fg=NAVY).pack(anchor='w')
                if e.get('degree'):
                    tk.Label(ei, text=e['degree'], font=FONT_SM, bg=SURF, fg=MUTED).pack(anchor='w')

        # Skills
        if p.get('skills'):
            tk.Label(col2, text="SKILLS", font=("Segoe UI",8,"bold"), bg=WH, fg=MUTED).pack(anchor='w', pady=(8,2))
            stags = tk.Frame(col2, bg=WH)
            stags.pack(anchor='w')
            row_frame = tk.Frame(stags, bg=WH)
            row_frame.pack(anchor='w')
            count = 0
            for s in p['skills'][:10]:
                if count and count % 4 == 0:
                    row_frame = tk.Frame(stags, bg=WH)
                    row_frame.pack(anchor='w')
                tk.Label(row_frame, text=s, font=("Segoe UI",8), bg=TAG_BG, fg=TAG_FG,
                         padx=6, pady=2).pack(side='left', padx=2, pady=1)
                count += 1

    def _open_url(self, url):
        import webbrowser
        webbrowser.open(url)

    # ── SCRAPE ACTION ───────────────────────────────────
    def _run_scrape(self):
        cookie = self.cookie.get().strip()
        if not cookie:
            messagebox.showerror("No Cookie", "Add your li_at cookie in the ⚙️ Cookie Setup tab first.")
            return
        raw = self.url_text.get('1.0','end').strip()
        urls = [l.strip() for l in raw.splitlines() if l.strip() and 'linkedin' in l]
        if not urls:
            messagebox.showerror("No URLs", "Enter at least one LinkedIn profile URL.")
            return

        self.scrape_btn.config(state='disabled', text="⏳ Scraping…")
        self.scrape_progress.start(10)
        self.status_var.set(f"Scraping {len(urls)} profile(s)…")

        def worker():
            profiles = []
            for i, url in enumerate(urls):
                self.status_var.set(f"Scraping {i+1}/{len(urls)}: {url[:50]}…")
                try:
                    slug = get_slug(url)
                    p = fetch_profile(slug, cookie)
                    profiles.append(p)
                except Exception as e:
                    profiles.append({'name': f'Error: {url}', 'headline': str(e),
                                     'url': url, 'experience':[], 'education':[], 'skills':[]})
                time.sleep(0.8)  # polite rate limiting

            self.after(0, lambda: self._scrape_done(profiles))

        threading.Thread(target=worker, daemon=True).start()

    def _scrape_done(self, profiles):
        self.scrape_btn.config(state='normal', text="⚡ Scrape Profiles")
        self.scrape_progress.stop()
        ok = sum(1 for p in profiles if not p.get('name','').startswith('Error:'))
        self.status_var.set(f"Done — {ok}/{len(profiles)} profiles scraped successfully.")
        self._show_results(profiles, 'scrape')

    # ── SEARCH ACTION ───────────────────────────────────
    def _run_search(self):
        cookie = self.cookie.get().strip()
        if not cookie:
            messagebox.showerror("No Cookie", "Add your li_at cookie in the ⚙️ Cookie Setup tab first.")
            return
        kw  = self.s_keywords.get().strip()
        loc = self.s_location.get().strip()
        if not kw and not loc:
            messagebox.showerror("Empty", "Enter keywords or a location to search.")
            return
        # Ignore placeholder text
        if kw in ("e.g. Priya Sharma engineer",): kw = ''
        if loc in ("e.g. Mumbai, Bangalore",): loc = ''

        n = int(self.s_count.get() or 10)

        self.search_btn.config(state='disabled', text="⏳ Searching…")
        self.search_progress.start(10)
        self.status_var.set(f"Searching LinkedIn for '{kw} {loc}'.strip()…")

        def worker():
            try:
                results = search_people(kw, loc, n, cookie)
                # Apply gender filter
                gf = self.gender_filter.get()
                if gf != 'Any':
                    results = [r for r in results if
                               (gf=='Female' and any(r['name'].split()[0].lower().startswith(fn)
                                for fn in ['priya','anita','neha','pooja','sara','sara','emma','emily','lisa','jennifer','mary','linda','susan','karen','michelle','laura','amanda','stephanie','melissa','rebecca','sophia','isabella','mia','chloe','hannah','grace','divya','anjali','kavya','meera','nisha','riya','shreya']))
                               or
                               (gf=='Male' and not any(r['name'].split()[0].lower().startswith(fn)
                                for fn in ['priya','anita','neha','pooja','sara','emma','emily','lisa','jennifer','mary','linda','susan','karen','michelle','laura','amanda','stephanie','melissa','rebecca','sophia','isabella','mia','chloe','hannah','grace','divya','anjali','kavya','meera','nisha','riya','shreya']))]
                self.after(0, lambda: self._search_done(results))
            except Exception as e:
                self.after(0, lambda: self._search_error(str(e)))

        threading.Thread(target=worker, daemon=True).start()

    def _search_done(self, results):
        self.search_btn.config(state='normal', text="🔍 Search LinkedIn")
        self.search_progress.stop()
        self.status_var.set(f"Found {len(results)} profiles.")
        self._show_results(results, 'search')

    def _search_error(self, msg):
        self.search_btn.config(state='normal', text="🔍 Search LinkedIn")
        self.search_progress.stop()
        self.status_var.set(f"Error: {msg}")
        messagebox.showerror("Search Failed", msg)

    # ── EXPORT ──────────────────────────────────────────
    def _export(self, fmt, tag):
        results = getattr(self, f'{tag}_results', [])
        if not results:
            messagebox.showinfo("No data", "Scrape or search first to get results.")
            return
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        if fmt == 'json':
            path = filedialog.asksaveasfilename(
                defaultextension='.json',
                initialfile=f'linkedin_{tag}_{ts}.json',
                filetypes=[('JSON', '*.json')]
            )
            if path:
                with open(path,'w',encoding='utf-8') as f:
                    json.dump(results, f, indent=2, ensure_ascii=False)
                messagebox.showinfo("Exported", f"Saved to {path}")
        elif fmt == 'csv':
            path = filedialog.asksaveasfilename(
                defaultextension='.csv',
                initialfile=f'linkedin_{tag}_{ts}.csv',
                filetypes=[('CSV', '*.csv')]
            )
            if path:
                keys = ['name','headline','location','about','url','followers','connections']
                with open(path,'w',newline='',encoding='utf-8') as f:
                    w = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
                    w.writeheader()
                    for p in results:
                        row = {k: p.get(k,'') for k in keys}
                        # Flatten lists
                        for k in keys:
                            if isinstance(row[k], list):
                                row[k] = '; '.join([str(x) for x in row[k]])
                        w.writerow(row)
                messagebox.showinfo("Exported", f"Saved to {path}")


if __name__ == '__main__':
    app = LinkedInScraper()
    app.mainloop()
