#!/bin/bash
echo "Installing dependencies..."
pip3 install -r requirements.txt
echo "Starting LinkedIn Scraper..."
python3 scraper.py
