LinkedIn Profile Scraper - Desktop App
========================================
Uses LinkedIn's Voyager API with your session cookie.
No paid plans. No API keys. 100% free.

SETUP (one time):
-----------------
1. Open linkedin.com in Chrome and log in
2. Press F12 -> Application -> Cookies -> linkedin.com
3. Find "li_at" -> copy its Value
4. Paste in the app's "Cookie Setup" tab -> Save

WINDOWS:
  Double-click run_windows.bat
  OR: python scraper.py

MAC / LINUX:
  ./run_mac_linux.sh
  OR: python3 scraper.py

REQUIREMENTS:
  Python 3.8+  (python.org)
  pip install requests

FEATURES:
  - Scrape any public LinkedIn profile by URL
  - Search people by name, keywords, location
  - Filter by gender
  - Export to JSON or CSV
  - Real data: name, headline, location, about,
    experience, education, skills, followers

COOKIE EXPIRY:
  li_at cookies last ~4 weeks. If you get 401 errors,
  get a fresh cookie from linkedin.com.
